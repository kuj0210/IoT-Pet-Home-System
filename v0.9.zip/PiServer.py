import requests
from requests_toolbelt import MultipartEncoder
from flask import Flask,jsonify,request
from PiInitSetting import PiSetting
from PiMessage import PiMessage
from FeedOperation import FeedOperation
from WaterOperation import WaterOperation
from DoorOperation import DoorOperation
#import picamera

message = PiMessage()

mPiSetting = PiSetting()
mPiSetting.ReadConfigFile()
resultByServer = mPiSetting.sendPiSettingData()

flag = {
    "isWater": False,
    "isFeed": False,
    "isDoor": False,
    "isCamera" : False
}
operationURL = "/" + mPiSetting.getPiKey() + "/operation"

#def postFileToServer(operation):
#    url = "http://localhost:8080/upload"
#    filename = "image/" + operation + ".jpg"
#    print("Post Server :" + url + ", filename : " + filename);
#    f = open(filename, 'rb')
#    m = MultipartEncoder({'image': (f.name, f, 'text/plain')})
#    try:
#        responese = requests.post(url, data=m, headers={'Content-Type': m.content_type})
#    except:
#        print("Post is Failed, maybe Server is Down or URL is incorrect.")
#
#    data = responese.json()
#    if data["result"] == True :
#        filelink = "http://localhost:8080/download/" + filename
#    else : # data["result"] == False :
#        filelink = "Image : None"
#    return filelink

app = Flask(__name__)

@app.route(operationURL, methods=["POST"])
def getOperationByServer():
    data = request.get_json()
    operation = data["operation"]
    sendMSG = ""
    if "feed" in operation:
        if flag["isFeed"] is False:
            flag["isFeed"] = True
            feedOperation = FeedOperation()
            result, flag["isFeed"] = feedOperation.run()
            flag["isFeed"] = False

            if result == "success":
                #filelink = postFileToServer("feed")

                if sendMSG == "":
                    sendMSG += message.getSuccessFeedMessage()# +"\n\n" + filelink
                else: #sendMSG is not None:
                    sendMSG += "\n\n" + message.getSuccessFeedMessage()# +"\n\n" + filelink
            else: #flag["isFeed"] is "fail":
                if sendMSG == "":
                    sendMSG += message.getFailFeedMessage()
                else: #sendMSG is not None:
                    sendMSG += "\n\n" + message.getFailFeedMessage()
        else:  # flag["isFeed"] is True
            if sendMSG == "":
                sendMSG += message.getContinueFeedMessage()
            else:  # sendMSG is not None:
                sendMSG += "\n\n" + message.getContinueFeedMessage()


    if "water" in operation:
        if flag["isWater"] is False:
            flag["isWater"] = True
            waterOperation = WaterOperation()
            result, flag["isWater"] = waterOperation.run()
            flag["isWater"] = False

            if result == "success":
                #filelink = postFileToServer("water")

                if sendMSG == "":
                    sendMSG += message.getSuccessWaterMessage()# +"\n\n" + filelink
                else: #sendMSG is not None:
                    sendMSG += "\n\n" + message.getSuccessWaterMessage()# +"\n\n" + filelink
            else: #flag["isWater"] is "fail":
                if sendMSG == "":
                    sendMSG += message.getFailWaterMessage()
                else: #sendMSG is not None:
                    sendMSG += "\n\n" + message.getFailWaterMessage()
        else:  # flag["isWater"] is True
            if sendMSG == "":
                sendMSG += message.getContinueWaterMessage()
            else:  # sendMSG is not None:
                sendMSG += "\n\n" + message.getContinueWaterMessage()

    if "open" in operation:
        if flag["isDoor"] is False:
            flag["isDoor"] = True
            doorOperation = DoorOperation()
            result, flag["isDoor"] = doorOperation.run()
            flag["isDoor"] = False

            if result == "success":
                #filelink = postFileToServer("door")

                if sendMSG == "":
                    sendMSG += message.getSuccessDoorMessage()# +"\n\n" + filelink
                else:  # sendMSG is not None:
                    sendMSG += "\n\n" + message.getSuccessDoorMessage()# +"\n\n" + filelink
            else:  # flag["isDoor"] is "fail":
                if sendMSG == "":
                    sendMSG += message.getFailDoorMessage()
                else:  # sendMSG is not None:
                    sendMSG += "\n\n" + message.getFailDoorMessage()
        else:  # flag["isDoor"] is True
            if sendMSG == "":
                sendMSG += message.getContinueDoorMessage()
            else:  # sendMSG is not None:
                sendMSG += "\n\n" + message.getContinueDoorMessage()

    postToServerMessage = {"message": {"text": sendMSG } }

    return jsonify(postToServerMessage)


if __name__ == "__main__":
    if resultByServer == "ok":
        app.run(host='0.0.0.0', port=8888, debug = True)
    else:
        print("RaspberryPi connection with server is denied or disconnected")