class DBString:
    def __init__(self):
        # DB 정보관리 , 테이블 명칭 변경 시 모든 쿼리에 적용
        self.DB_NAME = "SystemData"
        self.USER_TABLE_NAME = "naverUser"
        self.SERIAL_TABLE_NAME = "mobileSystem"
        self.REQUEST_NAME = "request"
        # 쿼리문 관리

        ##DB사용 쿼리문
        self.USE_DB_QUERY = "use %s;" % (self.DB_NAME)

        # 전달문자관리
        ##성공
        self.SUCESS_TO_REGIST = "등록 완료"
        self.SUCESS_DEL_NO_REGISTERD_USER = "미등록 유저입니다. 모든 정보들이 삭제되었습니다"
        self.SUCESS_DEL_REGISTERD_USER = "등록 시 넣은 정보들이 정상 삭제 되었습니다."

        ##테이블 생성쿼리문
        self.CREATE_DB_QUERY = '''
		    	create database %s 
			    	DEFAULT CHARACTER 
			    	SET utf8 collate utf8_general_ci;
                    %s
			    ''' % (self.DB_NAME, self.USE_DB_QUERY)

        self.CREATE_USER_TABLE_QUERY = '''
			    create table %s(
				    user_key varchar(50),
				    serial varchar(50),
				    primary key (user_key,serial)
				    ) ENGINE=InnoDB default character set utf8 collate utf8_general_ci;
		    ''' % (self.USER_TABLE_NAME)

        self.CREATE_SERIAL_TABLE_QUERY = '''
			    create table %s(
				    serial varchar(50),
				    ) ENGINE=InnoDB default character set utf8 collate utf8_general_ci;
			    ''' % (self.SERIAL_TABLE_NAME)
        self.CREATE_REQUEST_TABLE_QUERY = '''
			    create table %s(
				    serial varchar(50),
				    requestor varchar(50),
					request varchar(50),
					FOREIGN KEY (serial) REFERENCES %s (serial)
				    ) ENGINE=InnoDB default character set utf8 collate utf8_general_ci;
			    ''' % (self.REQUEST_NAME, self.SERIAL_TABLE_NAME)

        ##테이블 선택 쿼리문
        self.SELECT_USER_TABLE_QUERY = "select * from %s;" % (self.USER_TABLE_NAME)
        self.SELECT_SERIAL_TABLE_QUERY = "select * from %s;" % (self.SERIAL_TABLE_NAME)
        self.SELECT_REQUEST_TABLE_QUERY = "select * from %s;" % (self.REQUEST_NAME)

    # 유저관련 쿼리문
    def getQ_ST_U_FromUserKey(self, user_key):
        return "select user_key from %s where %s.user_key = \"%s\";" % (
			self.USER_TABLE_NAME, self.USER_TABLE_NAME, user_key)

    def getQ_ST_U_FromSerial(self, serial):
        return "select user_key from %s where %s.serial = \"%s\";" % (
			self.USER_TABLE_NAME, self.USER_TABLE_NAME, serial)

    def getQ_ST_U_FromUserKey_Serial(self, user_key, serial):
        return "select * from %s where %s.user_key=\"%s\" and user_key.serial=\"%s\";" % (
			self.USER_TABLE_NAME , user_key, self.USER_TABLE_NAME, serial)

    def getQ_IT_U(self, user_key, serial):
        return "insert into %s values (\"%s\", \"%s\");" % (
			self.USER_TABLE_NAME, user_key, serial)

    def getQ_DT_U(self, user_key):
        return "delete from %s where %s.user_key =\"%s\";" % (
			self.USER_TABLE_NAME, self.USER_TABLE_NAME, user_key)

    # 시리얼 관련 쿼리문
    def getQ_ST_S_FromSerial(self, serial):
        return "select * from %s where %s.serial = \"%s\";" % (
			self.SERIAL_TABLE_NAME, self.SERIAL_TABLE_NAME, serial)

    def getQ_ST_S_FromUser(self, user_key):
        return "select %s.serial from %s where %s.user_key = \"%s\";" % (
			self.USER_TABLE_NAME, self.USER_TABLE_NAME, self.USER_TABLE_NAME, user_key)

    # 리퀘스트 관련 쿼리문
    def getQ_IT_R_Value(self, user_key, serial, request):
        return "insert into %s values (\"%s\", \"%s\",\"%s\");" % (
			self.REQUEST_NAME, serial, user_key, request)

    def getQ_ST_RQST_From_SR(self, serial):
        return "select * from %s where %s.serial = \"%s\";" % (
			self.REQUEST_NAME, self.REQUEST_NAME, serial)

    def getQ_DT_RQST_From_SR(self, serial):
        return "delete from %s where %s.serial = \"%s\";" % (
			self.REQUEST_NAME, self.REQUEST_NAME, serial)


if __name__ == "__main__":
    sql = DBString()
    str = sql.getQ_ST_S_FromUser("u9-NF6yuZ8H8TAgj1uzqnQ")
    print(str)
