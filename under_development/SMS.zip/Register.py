import pymysql
from DBString import *
from defaultMessage import*
class Register:
	def __init__(self):
		self.mMsgList=MessageList()
		# DB 계정정보 관리
		self.conn = None
		self.curs = None
		self.serial = None
		self.host = "localhost"
		self.user = "root"
		self.pw = "root"
		self.charset = "utf8"

		#로그 정보
		self.LOG = "DB_LOG"
		#전달 문자
		self.SQL =  DBString()
		

	def connectDB(self):
		self.conn = pymysql.connect(host=self.host, user=self.user, password=self.pw, charset=self.charset)
		self.curs = self.conn.cursor()
		try:
			with self.conn.cursor() as self.curs:
				self.curs.execute(self.SQL.USE_DB_QUERY)
		except:
			with self.conn.cursor() as self.curs:
				self.curs.execute(self.SQL.CREATE_DB_QUERY)
			self.conn.commit()

			with self.conn.cursor() as self.curs:
				self.curs.execute(self.SQL.USE_DB_QUERY)

	def checkUserTable(self):	   
			try:
				with self.conn.cursor() as self.curs:
					self.curs.execute(self.SQL.SELECT_USER_TABLE_QUERY)
			except:
				with self.conn.cursor() as self.curs:
					self.curs.execute(self.SQL.CREATE_USER_TABLE_QUERY)
			self.conn.commit()

	def checkSystemTable(self):
		try:
			with self.conn.cursor() as self.curs:
				self.curs.execute(self.SQL.SELECT_SERIAL_TABLE_QUERY)
		except:
			with self.conn.cursor() as self.curs:
				self.curs.execute(self.SQL.CREATE_SERIAL_TABLE_QUERY)
		self.conn.commit()

	def requestTable(self):
		try:
			with self.conn.cursor() as self.curs:
				self.curs.execute(self.SQL.SELECT_REQUEST_TABLE_QUERY)
		except:
			with self.conn.cursor() as self.curs:
				self.curs.execute(self.SQL.CREATE_REQUEST_TABLE_QUERY)
		self.conn.commit()

	def openDB(self):
		self.connectDB()
		self.checkUserTable()
		self.checkSystemTable()
		self.requestTable()

	def closeDB(self):
		self.conn.close()

	def checkRegistedUserForOuter(self, user_key):
		self.openDB()
		try:
			with self.conn.cursor() as self.curs:
				query = self.SQL.getQ_ST_U_FromUserKey(user_key)
				self.curs.execute(query)
				rows = self.curs.fetchall()
				self.closeDB()
				if len(rows) > 0: 
					return True
				else:
					return False
		except:
				self.closeDB()
				return False
			
	def checkRegistedUser(self, user_key):
		try:
			with self.conn.cursor() as self.curs:
				query = self.SQL.getQ_ST_U_FromUserKey(user_key)
				self.curs.execute(query)
				rows = self.curs.fetchall()
				if len(rows) > 0: 
					return True
				else:
					return False
		except:
				return False
		
	def checkRegistedSerial(self, serial):
		try:
			with self.conn.cursor() as self.curs:
				query = self.SQL.getQ_ST_S_FromSerial(serial)
				self.curs.execute(query)
				rows = self.curs.fetchall()
				if len(rows) > 0: 
					return True
				else :
					return False

		except:
				return False

	def insertUserData(self, user_key, serial):
		self.openDB()
		with self.conn.cursor() as self.curs:
			if self.checkRegistedUser(user_key) == True:
				return self.mMsgList.ERR_REGISTERD_USER
			try:
				if self.checkRegistedSerial(serial) == False:
					return self.mMsgList.ERR_NO_REGISTERD_SERIAL
				
				with self.conn.cursor() as self.curs:
					self.curs.execute(self.SQL.getQ_IT_U(user_key,serial))
					self.conn.commit()
				self.closeDB()
				return self.mMsgList.SUCESS_IST_USER
			except:
				self.closeDB()
				return self.mMsgList.ERR_REGISTE_USER
	
	def insertUserRequest(self, user_key, rqst):
		self.openDB()
		if self.checkRegistedUser(user_key) == False:
				return self.mMsgList.ERR_NO_REGISTERD_USER
		SR =self.getSerialFromUser(user_key)
		
		with self.conn.cursor() as self.curs:
			try:
				with self.conn.cursor() as self.curs:
					self.curs.execute(self.SQL.getQ_IT_R_Value(user_key,SR,rqst))
					self.conn.commit()
				self.closeDB()
				return self.mMsgList.SUCESS_RECEVIED_MSG
			except:
				print("인서트예외")
				self.closeDB()
				return self.mMsgList.ERR_RECEVIED_MSG

	def fetchRequest(self,SR):
		self.openDB()
		with self.conn.cursor() as self.curs:
			if self.checkRegistedSerial(SR) == False:
				return self.mMsgList.ERR_NO_REGISTERD_SERIAL
			try:
				with self.conn.cursor() as self.curs:
					self.curs.execute(self.SQL.getQ_ST_RQST_From_SR(SR))
					list=self.curs.fetchall()
					if len(list)<=0:
						return False
					self.curs.execute(self.SQL.getQ_DT_RQST_From_SR(SR))
					self.conn.commit()
				self.closeDB()
				return self.listToString(list)
			except:
				self.closeDB()
				return

	def deleteUserData(self, user_key):
		self.openDB()
		with self.conn.cursor() as self.curs:
			if self.checkRegistedUser(user_key) == False:
				return self.mMsgList.SUCESS_DEL_NO_REGISTERD_USER
			try:
				with self.conn.cursor() as self.curs:
					self.curs.execute(self.SQL.getQ_DT_U(user_key))
					self.conn.commit()
				self.closeDB()
				return self.mMsgList.SUCESS_DEL_REGISTERD_USER
			except:
				self.closeDB()
				return  self.mMsgList.ERR_DEL_REGISTERD_USER

	def getSerialFromUser(self,user_key):
		with self.conn.cursor() as self.curs:
			if self.checkRegistedUser(user_key) == False:
				return self.mMsgList.ERR_NO_REGISTERD_USER
			try:
				with self.conn.cursor() as self.curs:	
					self.curs.execute(self.SQL.getQ_ST_S_FromUser(user_key))
					SR = self.curs.fetchall()
					
					if len(SR)<=0:
						return False
				return SR[0][0]
			except:
				print("getsr시리얼 예외")
				return  self.mMsgList.ERR_SCH_SR

	def getUserFromSerial(self,SR):
		with self.conn.cursor() as self.curs:
			if self.checkRegistedSerial(SR) == False:
				return self.mMsgList.ERR_NO_REGISTERD_SERIAL
			try:
				with self.conn.cursor() as self.curs:
					self.curs.execute(self.SQL.getQ_ST_U_FromSerial(SR))
					UK = self.curs.fetchall()	
					if len(UK)<=0:
						return False
				
				return self.listToString(UK)
			except:
				print("겟유저프롬 예외")
				return  self.mMsgList.ERR_SCH_UK
	def listToString(self,list):
		print(list)
		str=""
		for item in list:
			for atom in item:
				str+=atom+" "
			str+="\n"
		return str

if __name__=="__main__":
	user ="u9-NF6yuZ8H8TAgj1uzqnQ"
	Reg =Register()
	
	print(Reg.insertUserRequest(user,"TEST1 TEST2 TEST3"))
	print(Reg.insertUserRequest("testor","TEST4"))


