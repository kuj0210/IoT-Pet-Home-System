GRAVITY_N = 60  # if it meet N list, think true
GRAVITY_ANY = 40  # if it meet N or V list  think true
GRAVITY_ALL = 100  # if it meet N or V list  think true