import pymysql
from .query import create, delete, insert, select, util
from reply import reply
from reply import exception

class Register:
	def __init__(self):
		# DB 계정정보 관리
		self.conn = None
		self.curs = None
		self.serial = None

		#로그 정보
		self.LOG = "DB_LOG"

	def connectDB(self):
		from . import dbcon
		self.conn = pymysql.connect(
			host=dbcon.host, user=dbcon.user, password=dbcon.pw, charset=dbcon.charset)
		self.curs = self.conn.cursor()
		try:
			self.curs.execute(util.USE_DB_QUERY)
		except:
			self.curs.execute(create.DB_QUERY)
			self.conn.commit()
			self.curs.execute(util.USE_DB_QUERY)

	def checkUserTable(self):
		self.curs = self.conn.cursor()
		try:
			self.curs.execute(select.USER_TABLE_QUERY)
		except:
			self.curs.execute(create.USER_TABLE_QUERY)
			self.conn.commit()

	def checkSystemTable(self):
		self.curs = self.conn.cursor()
		try:
			self.curs.execute(select.SERIAL_TABLE_QUERY)
		except:
			self.curs.execute(create.SERIAL_TABLE_QUERY)
			self.conn.commit()

	def checkRequestTable(self):
		self.curs = self.conn.cursor()
		try:
			self.curs.execute(select.REQUEST_TABLE_QUERY)
		except:
			self.curs.execute(create.REQUEST_TABLE_QUERY)
		self.conn.commit()

	def openDB(self):
		self.connectDB()
		self.checkUserTable()
		self.checkSystemTable()
		self.checkRequestTable()

	def closeDB(self):
		self.conn.close()

	def checkRegistedUserForOuter(self, user_key):
		self.openDB()
		self.curs = self.conn.cursor()
		try:
			self.curs.execute(select.userKeyByUserKey(user_key))
			rows = self.curs.fetchall()
			self.closeDB()

			if len(rows) > 0:
				return True
			else:
				return False
		except:
			self.closeDB()
			return False
			
	def checkRegistedUser(self, user_key):
		self.openDB()
		self.curs = self.conn.cursor()
		try:
			self.curs.execute(select.userKeyByUserKey(user_key))
			rows = self.curs.fetchall()
			self.closeDB()

			if len(rows) > 0:
				return True
			else:
				return False

		except:
			self.closeDB()
			return False
		
	def checkRegistedSerial(self, serial):
		self.openDB()
		self.curs = self.conn.cursor()
		try:
			self.curs.execute(select.userKeyByUserKey(serial))
			rows = self.curs.fetchall()
			self.closeDB()

			if len(rows) > 0:
				return True
			else :
				return False
		except:
			self.closeDB()
			return False

	def insertUserData(self, user_key, serial):
		self.openDB()
		self.curs = self.conn.cursor()

		if self.checkRegistedUser(user_key) == True:
			return exception.REGISTERD_USER

		try:
			if self.checkRegistedSerial(serial) == False:
				return exception.NO_REGISTERD_SERIAL

			self.curs.execute(insert.userTable(user_key,serial))
			self.conn.commit()
			self.closeDB()
			return reply.SUCESS_IST_USER
		except:
			self.closeDB()
			return exception.DONT_REGIST
	
	def insertUserRequest(self, user_key, request):
		self.openDB()
		self.curs = self.conn.cursor()

		if self.checkRegistedUser(user_key) == False:
			return exception.NO_REGISTERD_USER
		serial = self.getSerialFromUser(user_key)

		try:
			self.curs.execute(insert.requestTable(user_key, serial, request))
			self.conn.commit()
			self.closeDB()
			return reply.SUCESS_RECEVIED_MSG
		except:
			print("인서트예외")
			self.closeDB()
			return exception.UNSUPPORTED_TYPE_COMMAND

	def fetchRequest(self, serial):
		self.openDB()
		self.curs = self.conn.cursor()

		if self.checkRegistedSerial(serial) == False:
			return exception.NO_REGISTERD_SERIAL

		try:
			self.curs.execute(select.requestBySerial(serial))
			rows=self.curs.fetchall()

			if len(rows)<=0:
				self.closeDB()
				return False

			self.curs.execute(delete.requestBySerial(serial))
			self.conn.commit()
			self.closeDB()
			return self.listToString(rows)
		except:
			self.closeDB()
			return

	def deleteUserData(self, user_key):
		self.openDB()
		self.curs = self.conn.cursor()

		if self.checkRegistedUser(user_key) == False:
			return reply.SUCESS_DEL_NO_REGISTERD_USER
		try:
			self.curs.execute(delete.userTableByUserKey(user_key))
			self.conn.commit()
			self.closeDB()
			return reply.SUCESS_DEL_REGISTERD_USER
		except:
			self.closeDB()
			return  exception.DEL_REGISTERD_USER

	def getSerialFromUser(self,user_key):
		self.openDB()
		self.curs = self.conn.cursor()

		if self.checkRegistedUser(user_key) == False:
			return exception.NO_REGISTERD_USER
		try:
			self.curs.execute(select.userSerialByUserKey(user_key))
			rows = self.curs.fetchall()
			self.closeDB()
			if len(rows)<=0:
				return False
			return rows[0][0]
		except:
			print("getSerialFromUser error")
			self.closeDB()
			return  exception.SELECT_FROM_CHECKING_SERIAL

	def getUserFromSerial(self, serial):
		self.openDB()
		self.curs = self.conn.cursor()

		if self.checkRegistedSerial(serial) == False:
			return exception.NO_REGISTERD_SERIAL
		try:
			self.curs.execute(select.userKeyBySerial(serial))
			rows = self.curs.fetchall()
			self.closeDB()

			if len(rows)<=0:
				return False
				
			return self.listToString(rows)
		except:
			print("getUserFromSerial error")
			self.closeDB()
			return  exception.SELECT_FROM_CHECKING_USER

	def listToString(self,list):
		print(list)
		str=""
		for item in list:
			for atom in item:
				str+=atom+" "
			str+="\n"
		return str

if __name__=="__main__":
	user ="u9-NF6yuZ8H8TAgj1uzqnQ"
	Reg =Register()
	
	print(Reg.insertUserRequest(user,"TEST1 TEST2 TEST3"))
	print(Reg.insertUserRequest("testor","TEST4"))