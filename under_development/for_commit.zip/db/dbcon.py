host = "localhost"
user = "root"
pw = "root"
charset = "utf8"