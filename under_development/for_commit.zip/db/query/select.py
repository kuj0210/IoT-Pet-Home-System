from . import util

##테이블 선택 쿼리문
USER_TABLE_QUERY = "select * from %s;" % (util.USER_TABLE_NAME)
SERIAL_TABLE_QUERY = "select * from %s;" % (util.SERIAL_TABLE_NAME)
REQUEST_TABLE_QUERY = "select * from %s;" % (util.REQUEST_NAME)

def userKeyByUserKey(user_key):
    return "select user_key from %s where %s.user_key = \"%s\";" % (
		util.USER_TABLE_NAME, util.USER_TABLE_NAME, user_key)

def userKeyBySerial(serial):
    return "select user_key from %s where %s.serial = \"%s\";" % (
		util.USER_TABLE_NAME, util.USER_TABLE_NAME, serial)

def userByUserKeyAndSerial(user_key, serial):
    return "select * from %s where %s.user_key=\"%s\" and user_key.serial=\"%s\";" % (
		util.USER_TABLE_NAME , user_key, util.USER_TABLE_NAME, serial)

def serialBySerial(serial):
    return "select * from %s where %s.serial = \"%s\";" % (
		util.SERIAL_TABLE_NAME, util.SERIAL_TABLE_NAME, serial)

def userSerialByUserKey(user_key):
    return "select %s.serial from %s where %s.user_key = \"%s\";" % (
		util.USER_TABLE_NAME, util.USER_TABLE_NAME, util.USER_TABLE_NAME, user_key)

def requestBySerial(serial):
    return "select * from %s where %s.serial = \"%s\";" % (
		util.REQUEST_NAME, util.REQUEST_NAME, serial)