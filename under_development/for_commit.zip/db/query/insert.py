from . import util

def userTable(user_key, serial):
    return "insert into %s values (\"%s\", \"%s\");" % (
		util.USER_TABLE_NAME, user_key, serial)

def serialTable(serial):
    return "insert into %s values (\"%s\");" %(
        util.SERIAL_TABLE_NAME, serial)

def requestTable(user_key, serial, request):
    return "insert into %s values (\"%s\", \"%s\",\"%s\");" % (
		util.REQUEST_NAME, serial, user_key, request)