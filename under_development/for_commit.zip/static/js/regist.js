ttpRequest = new XMLHttpRequest();

function regist(this_form) {
    var serial_num = this_form.serial_num;
    var contents = this_form.contents.value;

    else if(title != "" && contents != ""){
        if(confirm("Do you want to submit this source code?")){
            var request = JSON.stringify({"title": title, "contents":contents});
            httpRequest.open("post","/regist",true);
            httpRequest.setRequestHeader('Content-Type', 'application/json');
            httpRequest.timeout = 2000;
            httpRequest.send(request);
            httpRequest.callback();
        }
    }
}

httpRequest.onload = function(){
    if(httpRequest.readyState == httpRequest.DONE){
        if(httpRequest.status == 200 || httpRequest.status == 201){
            alert("Submitting Complete.");
            location.replace("index.html");
        } else alert("Server error. (status code:"+ httpRequest.status+")");
    }
}

httpRequest.ontimeout = function (e) {
    alert("Timeout - Didn't connect with server.");
};