import RPi.GPIO as GPIO
import time
import threading

class FeedOperation(threading.Thread):
    def run(self):
        self.p.start(0)
        try:
            self.p.ChangeDutyCycle(18)
            time.sleep(1)
            self.p.ChangeDutyCycle(7)
            time.sleep(5)
            self.p.ChangeDutyCycle(1)
            time.sleep(4)
            self.p.stop()
        except KeyboardInterrupt:
            self.p.stop()
            return "fail", False

        GPIO.cleanup()
        return "success", False